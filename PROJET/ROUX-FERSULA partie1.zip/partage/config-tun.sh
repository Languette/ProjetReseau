gcc /mnt/partage/tunalloc.c -o /home/m1reseaux/tun

/home/m1reseaux/tun tun0 1

